import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';
import { User, AuthResponse } from '../models/models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private apiUrl = '/api/auth';
  currentUser = signal<User | null>(null);

  constructor(private http: HttpClient, private router: Router) {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    if (token && user) { try { this.currentUser.set(JSON.parse(user)); } catch {} }
  }

  login(email: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/login`, { email, password }).pipe(
      tap(res => { if (res.success) { localStorage.setItem('token', res.token); localStorage.setItem('user', JSON.stringify(res.user)); this.currentUser.set(res.user); } })
    );
  }

  register(data: any): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/register`, data).pipe(
      tap(res => { if (res.success) { localStorage.setItem('token', res.token); localStorage.setItem('user', JSON.stringify(res.user)); this.currentUser.set(res.user); } })
    );
  }

  logout() { localStorage.removeItem('token'); localStorage.removeItem('user'); this.currentUser.set(null); this.router.navigate(['/login']); }
  getToken(): string | null { return localStorage.getItem('token'); }
  isLoggedIn(): boolean { return !!this.getToken() && !!this.currentUser(); }
  isAdmin(): boolean { return this.currentUser()?.role === 'admin'; }
}
