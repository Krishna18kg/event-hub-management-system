import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from '../../shared/navbar/navbar.component';
import { EventService } from '../../services/event.service';
import { AuthService } from '../../services/auth.service';
import { Event } from '../../models/models';

@Component({
  selector: 'app-event-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, NavbarComponent, FormsModule],
  templateUrl: './event-detail.component.html',
  styleUrls: ['./event-detail.component.css']
})
export class EventDetailComponent implements OnInit {
  eventService = inject(EventService);
  auth = inject(AuthService);
  route = inject(ActivatedRoute);

  event: Event | null = null;
  loading = true;
  registering = false;
  registered = false;
  message = '';
  messageType: 'success' | 'error' = 'success';

  showPaymentModal = false;
  paymentStep = 1;
  selectedMethod = '';
  upiId = '';
  upiError = '';
  processing = false;

  upiApps = [
    { name: 'GPay', icon: '🟢', color: '#34A853' },
    { name: 'PhonePe', icon: '🟣', color: '#5F259F' },
    { name: 'Paytm', icon: '🔵', color: '#00BAF2' },
    { name: 'BHIM', icon: '🟠', color: '#FF6B00' },
    { name: 'Other UPI', icon: '💳', color: '#E63946' }
  ];

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id')!;
    this.eventService.getEvent(id).subscribe({
      next: (res: any) => { this.event = res.event; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  openPayment() {
    if (!this.auth.isLoggedIn()) { this.message = 'Please login to register for this event.'; this.messageType = 'error'; return; }
    if (this.event?.isFree) { this.register(); return; }
    this.showPaymentModal = true; this.paymentStep = 1; this.selectedMethod = ''; this.upiId = ''; this.upiError = '';
  }

  selectApp(appName: string) { this.selectedMethod = appName; this.paymentStep = 2; }

  validateUPI(): boolean {
    const upiRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9]+$/;
    if (!this.upiId) { this.upiError = 'UPI ID enter કરો'; return false; }
    if (!upiRegex.test(this.upiId)) { this.upiError = 'Valid UPI ID enter કરો (e.g. name@okaxis)'; return false; }
    this.upiError = ''; return true;
  }

  processPayment() {
    if (!this.validateUPI()) return;
    this.processing = true;
    setTimeout(() => {
      this.processing = false;
      this.paymentStep = 3;
      this.eventService.registerForEvent(this.event!._id).subscribe({
        next: () => { this.registered = true; this.message = '🎉 Payment successful! Registered!'; this.messageType = 'success'; },
        error: (err) => { this.message = err.error?.message || 'Already registered!'; this.messageType = 'error'; }
      });
    }, 2500);
  }

  downloadReceipt() {
    const receipt = `============================\n     EVENTHUB RECEIPT\n============================\nEvent  : ${this.event?.title}\nAmount : ₹${this.event?.price}\nUPI ID : ${this.upiId}\nDate   : ${new Date().toLocaleDateString()}\nStatus : PAID\nRef No : EVT${Date.now()}\n============================\nThank you for your payment!\n  `;
    const blob = new Blob([receipt], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `EventHub-Receipt-${Date.now()}.txt`; a.click();
    window.URL.revokeObjectURL(url);
  }

  closeModal() { this.showPaymentModal = false; this.paymentStep = 1; }

  register() {
    this.registering = true;
    this.eventService.registerForEvent(this.event!._id).subscribe({
      next: () => { this.registered = true; this.message = '🎉 Successfully registered!'; this.messageType = 'success'; this.registering = false; },
      error: (err) => { this.message = err.error?.message || 'Registration failed.'; this.messageType = 'error'; this.registering = false; }
    });
  }

  getPrice(): string {
    if (!this.event) return '';
    return this.event.isFree ? 'Free' : '₹' + this.event.price;
  }

  get ticketPercent(): number {
    if (!this.event) return 0;
    return Math.round(((this.event.totalTickets - this.event.availableTickets) / this.event.totalTickets) * 100);
  }
}
