import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { NavbarComponent } from '../../shared/navbar/navbar.component';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-user-queries',
  standalone: true,
  imports: [CommonModule, FormsModule, NavbarComponent],
  templateUrl: './queries.component.html',
  styleUrls: ['./queries.component.css']
})
export class UserQueriesComponent implements OnInit {
  http = inject(HttpClient);
  auth = inject(AuthService);
  queries: any[] = [];
  showModal = false;
  loading = false;
  submitting = false;
  message = '';
  messageType: 'success' | 'error' = 'success';
  form = { name: '', email: '', message: '', type: 'query' };

  ngOnInit() {
    const user = this.auth.currentUser();
    if (user) { this.form.name = user.name; this.form.email = user.email; }
    this.loadQueries();
  }

  loadQueries() {
    this.loading = true;
    this.http.get<any>('/api/feedback?type=query').subscribe({
      next: (res) => {
        const user = this.auth.currentUser();
        this.queries = (res.items || []).filter((q: any) => q.email === user?.email);
        this.loading = false;
      },
      error: () => { this.loading = false; }
    });
  }

  openModal() { this.showModal = true; this.message = ''; this.form.message = ''; }

  submitQuery() {
    if (!this.form.message.trim()) { this.message = 'Message type કરો!'; this.messageType = 'error'; return; }
    this.submitting = true;
    this.http.post('/api/feedback', this.form).subscribe({
      next: () => {
        this.submitting = false; this.showModal = false; this.form.message = '';
        this.message = '✅ Query submit થઈ! Admin reply કરશે.';
        this.messageType = 'success';
        this.loadQueries();
      },
      error: () => { this.message = 'Error! Try again.'; this.messageType = 'error'; this.submitting = false; }
    });
  }
}
