const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const connectDB = require('./config/db');

dotenv.config();
connectDB();

const app = express();
app.use(cors({ origin: 'http://localhost:4200', credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/events', require('./routes/events.routes'));
app.use('/api/admin', require('./routes/admin.routes'));
app.use('/api/feedback', require('./routes/feedback.routes'));

app.get('/api/health', (req, res) => res.json({ status: 'EventHub API running ✅' }));

app.get('/api/seed', async (req, res) => {
  try {
    const User = require('./models/User');
    const Event = require('./models/Event');
    const adminExists = await User.findOne({ email: 'admin@eventhub.com' });
    if (!adminExists) {
      await User.create({ name: 'Admin User', email: 'admin@eventhub.com', password: 'admin123', role: 'admin', phone: '9999999999', department: 'IT', year: '4' });
    }
    const eventsCount = await Event.countDocuments();
    if (eventsCount === 0) {
      const admin = await User.findOne({ role: 'admin' });
      await Event.insertMany([
        { title: 'Musical Fusion Festival', description: 'A spectacular fusion of world music genres', category: 'Music', date: new Date('2026-06-08'), location: 'New York, NY', price: 130, totalTickets: 500, availableTickets: 500, image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800', organizer: admin._id, status: 'active' },
        { title: 'Urban Marathon', description: 'Annual city marathon through scenic routes', category: 'Sports', date: new Date('2026-06-09'), location: 'Mumbai, India', price: 499, totalTickets: 1000, availableTickets: 1000, image: 'https://images.unsplash.com/photo-1571019613914-85f342c6a11e?w=800', organizer: admin._id, status: 'active' },
        { title: 'AI Summit 2026', description: 'Explore cutting-edge AI demos, robotics, AR/VR', category: 'Technology', date: new Date('2026-03-29'), location: 'Jio Conventional Center Mumbai', price: 249, totalTickets: 500, availableTickets: 500, image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800', organizer: admin._id, status: 'active' },
        { title: 'Melody Mania', description: 'Free entry music showcase for emerging artists', category: 'Music', date: new Date('2026-06-24'), location: 'Surat, Gujarat', isFree: true, price: 0, totalTickets: 200, availableTickets: 200, image: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=800', organizer: admin._id, status: 'active' },
        { title: 'Finance Conference', description: 'Learn about investment and financial planning', category: 'Business', date: new Date('2026-04-12'), location: 'Mumbai, India', price: 999, totalTickets: 500, availableTickets: 500, image: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=800', organizer: admin._id, status: 'active' },
        { title: 'Oil Painting Odyssey', description: 'Brushstrokes and Beyond - An immersive oil painting experience', category: 'Art', date: new Date('2026-06-07'), location: 'Sardar Smruti Bhavan, Surat', isFree: true, price: 0, totalTickets: 50, availableTickets: 50, image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=800', organizer: admin._id, status: 'active' },
        { title: 'Food Festival Surat', description: 'Taste cuisines from around the world', category: 'Food', date: new Date('2026-05-20'), location: 'VR Mall Surat', price: 299, totalTickets: 300, availableTickets: 300, image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800', organizer: admin._id, status: 'active' },
        { title: 'Corporate Summit', description: 'Business leaders and entrepreneurs', category: 'Business', date: new Date('2026-07-15'), location: 'Delhi, India', price: 1499, totalTickets: 500, availableTickets: 500, image: 'https://images.unsplash.com/photo-1431540015161-0bf868a2d407?w=800', organizer: admin._id, status: 'active' },
      ]);
    }
    res.json({ success: true, message: '✅ Seeded: admin@eventhub.com / admin123' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 EventHub Server running on http://localhost:${PORT}`));
